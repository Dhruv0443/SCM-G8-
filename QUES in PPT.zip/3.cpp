#include<iostream>
using namespace std;
int main()
{
    int a;
    cout<<"Enter a number";
    cin>>a;
    int i,n;
    while(i<a)
    {
      n =i*(i+1);
      i+=1;
    }
    cout<<"The factorial of a number is: "<<n<<endl;

    return 0;
}
