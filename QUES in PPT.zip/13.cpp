#include<iostream>
using namespace std;
int main()
{
    int age;
    cout<<"Enter your age : ";
    cin>>age;
    if (age<18)
    {
        cout<< "Not eligible";
    }
    else if(age>=18 and age<60)
    {
        cout<<"Eligible for vaccination with least priority";
    }
    else if(age<60)
    {
        cout<<"Eligible for vaccination with highest priority";
    }
    return 0;
}
