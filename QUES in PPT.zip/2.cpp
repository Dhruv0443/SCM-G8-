#include<iostream>
using namespace std;
int main()
{
    int a;
    cout<<"Enter first number : ";
    int b;
    cin>>a;
    cout<<"Enter Second number : ";
    cin>>b;
    int c;
    cout<<"Enter Third number : ";
    cin>>c;
    if(a>b and a>c)
    {
      cout<<a<<" is the greatest number."<<endl;
    }
    else if(b>a and b>c)
    {
        cout<<b<<" is the greatest number."<<endl;
    }
    else
    {
        cout<<c<<" is the greatest number."<<endl;
    }
    return 0;
}
