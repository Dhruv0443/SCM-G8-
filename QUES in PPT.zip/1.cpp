#include<iostream>
using namespace std;
int main()
{
    int num;
    cout<<"Enter a number : ";
    cin>>num;
    if(num%3==0)
    {
        cout<<num<<" is a multiple of 3."<<endl;
    }
    else if(num%7==0)
    {
        cout<<num<<" is a multiple of 7."<<endl;
    }
    else
    {
        cout<<num<<" is neither a multiple of 3 nor 7.";
    }
    return 0;
}
