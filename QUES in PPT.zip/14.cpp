#include<iostream>
using namespace std;
int main()
{
    int point;
    cout<< "Enter the Points.";
    cin>> point;
    if (point<10 and point>=9)
    {
        cout<< "A+";
    }
    else if(point>=8 and point<9)
    {
        cout<<"A";
    }
    else if(point>=7 and point<8)
    {
        cout<<"B+";
    }
    else if(point>=6 and point<7)
    {
        cout<<"B";
    }
    else if(point>=5 and point<6)
    {
        cout<<"C";
    }
    else if(point>=4 and point<5)
    {
        cout<<"D";
    }
    else if (point<4)
    {
        cout<<"Failed";
    }

    return 0;
}
