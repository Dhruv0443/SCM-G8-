#include <iostream>
using namespace std;
int main()
{
int num,sum=0,r;
cout<<"Enter a number: ";
cin>>num;
while(num>0)
{
m=num%10;
sum=sum+r;
num=num/10;
}
cout<<"Sum is= "<<sum<<endl;
return 0;
}
