#include<iostream>
using namespace std;
int main()
{
    int n,a=0;
    cout<<"Please enter a number : ";
    cin>>n;

    int i=0;
    do
    {
        a=a+i;
        i+=1;
    }while(i<=n);
    cout<<"Sum of first"<<n<<" number is :"<<a<<endl;
    return 0;
}
